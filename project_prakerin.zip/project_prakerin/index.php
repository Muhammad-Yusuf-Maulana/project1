<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>Movie House</title>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    
  </head>
  <body>

<div id="header">
    <div class="logo"><img src="assets/img/lgheader.png" style="width: 60px;"></div>
    <div class="searching">
      <input type="text" placeholder="search...">
      <button class="btn btn-outline-primary " type="submit">Search</button>
    </div>
      <nav>
        <ul class="menu">
          <li><a href="#">Buku</a></li>
          <li><a href="#" class="menu-item">Denda</a></li>
          <li class="sub-menu"><a href="../pengunjung/pengunjung.php" class="menu-item">Pengunjung</a>
            <ul>
            <li><a href="../anggota/buku.php" class="menu-item">Anggota</a></li>
            <li><a href="../petugas/buku.php" class="menu-item">Petugas</a></li>
          </ul>
          </li>
          <li class="sub-menu"><a href="../pendataan/buku.php" class="menu-item">Pendataan</a>
            <ul>
              <li><a href="../pembokingan/buku.php" class="menu-item">Pembokingan</a></li>
              <li><a href="#" class="menu-item">Pengembalian</a></li>
              <li><a href="#" class="menu-item">Peminjaman</a></li>
            </ul>
          </li>
          <li><a href="#" class="menu-item">Profil</a></li>
          <li><a href="#" class="menu-item">Log in</a></li>
          <li><a href="../index.php"  class="active"><i class="fas fa-home" style="font-size: 50px; line-height: 80px;"></i></a></li>
        </ul>
      </nav>
  <div class="menu-toggle"><i class="fa fa-bars" aria-hidden="true"></i></div>
</div><br><br><br><br>

<script type="text/javascript">
    $(document).ready(function(){
      $('.menu-toggle').click(function(){
        $('nav').toggleClass('active')
      })
      $('ul li').click(function(){
        $(this).siblings().removeClass('active');
        $(this).toggleClass('active');
      })
    })
</script>

<div class="bg-container">
  <img src="assets/img/image1.jpg" style="z-index: 1;">
    <div class="carousel-caption d-none d-md-block" style="z-index: 2;">
        <h1 class="bg1">WELLCOME</h1>
        <h3 class="text-dark">MOVIE HOUSE</h3>
    </div>
</div>

<section class="latar warnadrop bg2">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center text-white">
            <h1><b>KOLEKSI</b></h1>
          </div>
        </div>
        <div class="row marginatas">
          <div class="col-sm-3 text-center marginbawah text-white">
            <a href=""><img src="assets/img/foto1.jpg" class="img-thumbnail rounded-circle bg-dark lebar" width="200"></a>
            <h4><b>BUKU</b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah text-white">
            <a href=""><img src="assets/img/foto3.jpg" class="img-thumbnail rounded-circle bg-dark lebar" width="200"></a>
            <h4><b>JURNAL</b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah text-white">
            <a href=""><img src="assets/img/foto3.jpg" class="img-thumbnail rounded-circle bg-dark lebar" width="200"></a>
            <h4><b>JURNAL</b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
          <div class="col-sm-3 text-center marginbawah text-white">
            <a href=""><img src="assets/img/foto4.jpg" class="img-thumbnail rounded-circle bg-dark lebar" width="200"></a>
            <h4><b>KLIPING</b></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
      </div>
    </section>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/img/picture1.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block text-body">
        <h1>COOMING SOON</h1>
        <h3>Action</h3>
       </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/picture3.jpg" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
        <h1>COOMING SOON</h1>
        <h3>Horor</h3>
       </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/picture1.jpg" alt="Third slide">
      <div class="carousel-caption d-none d-md-block text-body">
        <h1 class="text-slide">COOMING SOON</h1>
        <h3>Comedy</h3>
       </div>
    </div>
  </div>
  <a class="carousel-control-prev bg1" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next bg1" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

 

<section>
      <div class="col-sm-12"><h1 class="colour text-center judul">LIST MOVIE</h1> </div>
  <div class="product">

    <div class="baris_kedua">
      <div class="box">
        <div class="imgBx">
          <img src="ghazi1.jpg" style="width: 400px; height: 600px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-buku.html"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>Laskar Pelangi<br/><span>Non-Fiksi</span></h2>
        </div>
      </div>
    </div>

     <div class="baris_kedua2">
      <div class="box">
        <div class="imgBx">
          <img src="Dilan__Dia_Adalah_Dilanku_Tahun_1990_New__Cover_Baru____ID__.jpg" style="width: 400px; height: 700px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-dilan.php"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>Dilan<br/><span>Non-Fiksi</span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua3">
      <div class="box">
        <div class="imgBx">
          <img src="laskar_pelangi.jpg" style="width: 400px; height: 700px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-buku-SiJuki.html"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>SiJuki<br/><span>Fiksi</span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua4">
      <div class="box">
        <div class="imgBx">
          <img src="cantikituluka.jpg" style="width: 400px; height: 700px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-buku-SiJuki.html"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>SiJuki<br/><span>Fiksi</span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua5">
      <div class="box">
        <div class="imgBx">
          <img src="naruto.jpg" style="width: 400px; height: 700px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-buku-SiJuki.html"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>SiJuki<br/><span>Fiksi</span></h2>
        </div>
      </div>
    </div>

    <div class="baris_kedua6">
      <div class="box">
        <div class="imgBx">
          <img src="juki1.jpg" style="width: 400px; height: 700px">
        </div>
          <ul class="social-icon">
            <li><a href="detail-buku-SiJuki.html"><i class="fas fa-address-book" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        <div class="details2">
          <h2>SiJuki<br/><span>Fiksi</span></h2>
        </div>
      </div>
    </div>
</section>

<div class="footer-top">
  <div class="konten1">
    <div class="line"></div>
          <h3>MOVIE</h3>
          <h3>HOUSE</h3>
          <P>Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca,  dipencet, disearching. dan lain-lainnya Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya
          </P>
  </div>
  <div class="konten2">
    <h5>USEFUL LINKS</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <li>Home</li><hr class="line2">
          <li>Busines</li><hr class="line2">
          <li>Product</li><hr class="line2">
          <li>About Us</li><hr class="line2">
          <li>Contact Us</li><hr class="line2">
  </div>
  <div class="konten3">
    <h5>FOLLOW US</h5>
          <div class="line2">
            <div class="l-line"></div>
            <li><a href="#"><i class="fab fa-twitter" style="margin-left: -60px; background-color: #333333; padding: 10px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" style="margin-left: -5px; background-color: #333333; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" style="margin-left: 10px; background-color: #333333; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-youtube" style="margin-left: 10px; background-color: #333333; padding: 10px 10px; border-radius: 100%;"></i></a></li>
          </div>
  </div>
  <div class="konten4">
    <h5>OUR NEWSLETTER</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <p>Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya</p>  
        <div class="search-ft">
          <input type="text" placeholder="search...">
          <button class="btn btn-outline-primary " type="submit">Search</button>
        </div>
  </div>
</div>
<div class="footer-bottom">
        <p>Hak Cipta © aln_0197 corporation</p>
</div>

<button id="topBtn"><i class="fas fa-arrow-up"></i></button>
<script type="text/javascript">
  $(document).ready(function(){
  $(window).scroll(function(){
    if($(this).scrollTop() > 40){
      $('#topBtn').fadeIn();
    } else{
      $('#topBtn').fadeOut();
    }
  });
    $("#topBtn").click(function(){
      $('html ,body').animate({scrollTop : 0},900);
    });
  });
</script>
<!-- ================================================================= -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script rel="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    
  </body>
</html>