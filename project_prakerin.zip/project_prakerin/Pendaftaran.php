<!DOCTYPE html>
<html>
<head>
	<title>FORM PERPUSTAKAAN</title>
	<meta name="viewport" content="width=device-width,initial--scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="Pendaftaran.css">
	<link rel="icon" type="image/png" href="Untitled-77.png">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	</head>
<body>
<div class="back">
		<a href="efek4.html"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
	</div>
	<h3><marquee> SILAHKAN ISI DENGAN BENAR</marquee></h3>
<div class="q">
	<form>
		<h2>PENDAFTARAN</h2>
		<input type="text" name="MasukkanNamaAnda" placeholder="Masukkan Nama Anda">
		<input type="email" name="Masukkan Email Anda" placeholder="MasukkanEmailAnda">
		<input type="number" name="MasukkanNomorHpAnda" placeholder="Masukkan Nomor Hp Anda">
		<input type="password" name="Masukkanpassword" placeholder="Masukkan Password">
		<input type="pw" name="confirmpassword" placeholder="Confirm Password">
		<br>
		<span style="font-size:18px;">Date Of Birth</span>
		<br>

		<select name="tanggal">
			<?php
				for ($i= 1; $i <= 31; $i++) 
				{
				echo "<option>$i</option>";
				}
			?>
		</select>

		<select name="bulan">
			<?php 
				$bulan=array("JANUARI","FEBRUARI","MARET","APRIL","MEI","JUNI","JULI","AGUSTUS","SEPTEMBER","NOVEMBER","DESEMBER");
			 ?>
			 <?php for($x=0; $x<=11; $x++) { ?>
			<option><?= $bulan[$x]; ?></option>
			<?php } ?>
			<!-- <option value="Februari">Februari</option>
			<option value="Maret">Maret</option>
			<option value="April">April</option>
			<option value="Mei">Mei</option>
			<option value="Juni">Juni</option>
			<option value="Juli">Juli</option>
			<option value="Agustus">Agustus</option>
			<option value="September">September</option>
			<option value="Oktober">Oktober</option>
			<option value="November">November</option>
			<option value="Desember">Desember</option> -->
		</select>

		<select name="Tahun">
			<?php
				for ($i= 2002; $i <= 2018; $i++) 
				{
				echo "<option>$i</option>";
				}
			?>
		</select>
<br>
		<br>
		<input type="radio" name="Laki-laki" value="Laki-laki">Laki-laki
		<input type="radio" name="Perempuan" value="Perempuan">Perempuan
		<br>
		<input type="checkbox"> Saya Setuju
		<br>
		<input type="submit" value="Submit Now">
	</form>
</div>
</body>
</html>