<!doctype html>
<html lang="en">
  <head>
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>Detail Dilan</title>
    <link rel="stylesheet" type="text/css" href="detail-dilan.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  </head>
  <body>
        <div class="back">
            <a href="index.php"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
        </div>
        <div class="boxtop"><h1> Trailler Dilan 1990</h1>
            <div class="embed-responsive embed-responsive-16by9">
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/X_b-wNkz4DU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
        <center>
        <div class="boxbottom"><h1>Dilan 1990</h1>
              <div class="cardleft">
                <img src="Dilan__Dia_Adalah_Dilanku_Tahun_1990_New__Cover_Baru____ID__.jpg" width="300">
              </div>

              <div class="titlebox">
                <div class="tb-top"><h3>SYNOPSIS</h3>
                    <li>>>    Movie Tayang: Mei-Juni 2017</li><hr>
                    <li>>>    Movie Theaters: mEI-jUNI 2017</li><hr>
                    <li>>>    Genre Action Drama Thriller</li><hr>
                    <li>>>    Movie Tayang: mEI-jUNI 2017</li><hr>
                    <li>>>    Movie Tayang: mEI-jUNI 2017</li><hr>
                </div>
                <div class="tb-bottom">
                  <p>PAGI, Bandung 1990. Kabut tipis hadir di sela sinar matahari yang masih malu menampakan diri. Suara motor tua memecah keheningan di awal hari itu.

Milea (Vanesha Prescilla) berjalan kaki menuju sekolah. Sudah hampir dua minggu dia sekolah di SMA yang terletak di Buahbatu, Bandung tersebut. 

Dia anak baru, pindahan dari Jakarta. Ibunya (Happy Salma) adalah orang Sunda, sedangkan ayahnya (M Farhan) seorang tentara dari Sumatera Barat. Milea tak pernah menyangka, pertemuan pertama dia dengan Dilan (Iqbaal Ramadhan) pagi itu akan mengubah hari-harinya.

Sosok Dilan dikenal badung di sekolah. Dia adalah panglima di geng motor terkenal di Bandung. Setiap ada kehebohan di sekolah, Dilan dan kawan-kawannya selalu menjadi biang onar. 
Pernah suatu hari, Dilan dan kawan-kawannya mabal upacara. Akibatnya, guru BP, Suripto (Teuku Rifnu Wikana) menyetrap Dilan dkk. saat upacara masih berlangsung. Kelakuan bandel Dilan yang lain adalah merubuhkan dinding pembatas kelas, karena kelas dia dan Milea bersebelahan.

Mulanya, Milea tidak menganggap Dilan. Dia kerap judes saat harus berhadapan si peramal --sebutan Milea untuk Dilan-- itu. Apalagi, Milea punya pacar di Jakarta, Beni (Brandon Salim). 
Namun, perhatian Dilan yang unik kepada Milea membuat gadis itu diam-diam memikirkan Dilan. Dilan menjadi sosok antimainstream di kehidupan Milea.

Saat cowok lain memberikan kado boneka saat Milea ulang tahun, Dilan malah memberi buku teka-teki silang dan surat pendek. Belum lagi kebiasaan-kebiasaan lucu Dilan saat menelefon Milea. Milea juga salut dengan keberanian Dilan main ke rumahnya dan bertemu ayahnya.</p>
                </div>
              </div>
              <div class="social">
            <center>
              <ul>
                <li>
                  <a href="#">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span class="fa fa-facebook" aria-hidden="true"></span>
                  </a>
                </li>

                <li>
                  <a href="#">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span class="fa fa-twitter" aria-hidden="true"></span>
                  </a>
                </li>

                <li>
                  <a href="#">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span class="fa fa-google-plus" aria-hidden="true"></span>
                  </a>
                </li>

                <li>
                  <a href="#">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span class="fa fa-youtube" aria-hidden="true"></span>
                  </a>
                </li>

                <li>
                  <a href="#">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span class="fa fa-linkedin" ariahidden="true"></span>
                  </a>
                </li>
              </ul>
            </center>
              <h2>MEDIA SOSIAL</h2>
            </div>
        </div>
        </center>
<button id="topBtn"><i class="fas fa-arrow-up"></i></button>
  <script type="text/javascript">
    $(document).ready(function(){
    $(window).scroll(function(){
      if($(this).scrollTop() > 40){
        $('#topBtn').fadeIn();
      } else{
        $('#topBtn').fadeOut();
      }
    });
      $("#topBtn").click(function(){
        $('html ,body').animate({scrollTop : 0},900);
      });
    });
</script>
        <div class="footer-top">
  <div class="konten1">
    <div class="line"></div>
          <h3>WEBSITE</h3>
          <h3>NAME</h3>
          <P>Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca,  dipencet, disearching. dan lain-lainnya Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya
          </P>
  </div>
  <div class="konten2">
    <h5>USEFUL LINKS</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <li>Home</li><hr class="line2">
          <li>Busines</li><hr class="line2">
          <li>Product</li><hr class="line2">
          <li>About Us</li><hr class="line2">
          <li>Contact Us</li><hr class="line2">
  </div>
  <div class="konten3">
    <h5>FOLLOW US</h5>
          <div class="line2">
            <div class="l-line"></div>
            <li><a href="#"><i class="fab fa-twitter" style="margin-left: -60px; background-color: #333333; padding: 10px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook" style="margin-left: -5px; background-color: #333333; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" style="margin-left: 10px; background-color: #333333; padding: 10px 12px; border-radius: 100%;"></i></a></li>
            <li><a href="#"><i class="fab fa-youtube" style="margin-left: 10px; background-color: #333333; padding: 10px 10px; border-radius: 100%;"></i></a></li>
          </div>
  </div>
  <div class="konten4">
    <h5>OUR NEWSLETTER</h5>
          <div class="line2">
            <div class="l-line"></div>
          </div>
          <p>Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya Ini tuh namanya footer, bukan tulisan biasa tapi bisa dibaca, dipencet, disearching. dan lain-lainnya</p>  
        <div class="search-ft">
          <input type="text" placeholder="search...">
          <button class="btn btn-outline-primary " type="submit">Search</button>
        </div>
  </div>
</div>
<div class="footer-bottom">
        <p>Hak Cipta © aln_0197 corporation</p>
</div>
    <!-- Optional JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script rel="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  </body>
</html>